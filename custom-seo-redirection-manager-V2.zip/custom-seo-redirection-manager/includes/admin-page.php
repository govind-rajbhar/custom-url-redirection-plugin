<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_menu', 'csrm_admin_menu' );
add_action( 'admin_enqueue_scripts', 'csrm_admin_enqueue_assets' );

function csrm_admin_menu() {

    global $csrm_plugin_hooks;

    $csrm_plugin_hooks   = array();
    $csrm_plugin_hooks[] = add_menu_page(
        __( 'SEO Redirects', 'custom-seo-redirection-manager' ),
        __( 'SEO Redirects', 'custom-seo-redirection-manager' ),
        'manage_options',
        'csrm-redirects',
        'csrm_admin_page',
        'dashicons-randomize',
        80
    );

    $csrm_plugin_hooks[] = add_submenu_page(
        'csrm-redirects',
        __( '404 Monitor', 'custom-seo-redirection-manager' ),
        __( '404 Monitor', 'custom-seo-redirection-manager' ),
        'manage_options',
        'csrm-404-monitor',
        'csrm_404_monitor_page'
    );
}

/**
 * Only load the plugin's CSS/JS on its own admin screens, and pass the
 * REST endpoint, a fresh nonce, and translated strings to the script via
 * wp_localize_script() rather than embedding them inline.
 */
function csrm_admin_enqueue_assets( $hook ) {

    global $csrm_plugin_hooks;

    if ( empty( $csrm_plugin_hooks ) || ! in_array( $hook, $csrm_plugin_hooks, true ) ) {
        return;
    }

    wp_enqueue_style(
        'csrm-admin',
        CSRM_URL . 'assets/css/admin.css',
        array(),
        CSRM_VERSION
    );

    wp_enqueue_script(
        'csrm-admin',
        CSRM_URL . 'assets/js/admin.js',
        array(),
        CSRM_VERSION,
        true
    );

    wp_localize_script(
        'csrm-admin',
        'CSRM_Admin',
        array(
            'restUrl'       => esc_url_raw( rest_url( 'csrm/v1/' ) ),
            'nonce'         => wp_create_nonce( 'wp_rest' ),
            'confirmDelete' => esc_html__( 'Delete this entry?', 'custom-seo-redirection-manager' ),
            'confirmClear'  => esc_html__( 'Clear all 404 logs? This cannot be undone.', 'custom-seo-redirection-manager' ),
        )
    );
}

/**
 * Validate/sanitize a submitted target URL.
 *
 * Regex-rule targets are replacement patterns (can contain $1, $2
 * backreferences) rather than literal URLs, so they only get light
 * sanitization. Non-regex targets are validated as either a well-formed
 * absolute URL or sanitized as a relative path.
 *
 * @return string|false Sanitized value, or false if validation fails.
 */
function csrm_validate_target_url( $target, $is_regex ) {

    if ( $is_regex ) {
        return sanitize_text_field( $target );
    }

    $is_absolute = ( 0 === strpos( $target, 'http://' ) || 0 === strpos( $target, 'https://' ) );

    if ( $is_absolute ) {
        return wp_http_validate_url( $target ) ? esc_url_raw( $target ) : false;
    }

    return esc_url_raw( $target );
}

/**
 * Normalize a submitted "source" value into the site-relative path (or
 * regex pattern) that matching actually runs against.
 *
 * - A literal absolute URL (scheme + host — e.g. someone pasted the full
 *   browser URL) has its domain stripped, since matching always happens
 *   against the path-only portion of the incoming request.
 * - Regex patterns are left untouched beyond outer whitespace, since
 *   running them through a URL parser would misread metacharacters like
 *   ? or # as a query string or fragment and silently truncate the
 *   pattern.
 * - A plain relative path just has leading/trailing slashes trimmed.
 */
function csrm_normalize_source( $source, $is_regex ) {

    $source = trim( $source );

    if ( preg_match( '#^https?://#i', $source ) ) {
        $path = wp_parse_url( $source, PHP_URL_PATH );
        return trim( (string) $path, '/' );
    }

    if ( $is_regex ) {
        return $source;
    }

    return trim( $source, '/' );
}

function csrm_admin_page() {

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    global $wpdb;

    $table  = csrm_get_redirect_table();
    $errors = array();

    if (
        isset( $_POST['csrm_add_redirect'] ) &&
        isset( $_POST['csrm_nonce'] ) &&
        wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['csrm_nonce'] ) ), 'csrm_save_redirect' )
    ) {

        $raw_source = isset( $_POST['source_url'] ) ? sanitize_text_field( wp_unslash( $_POST['source_url'] ) ) : '';
        $raw_target = isset( $_POST['target_url'] ) ? sanitize_text_field( wp_unslash( $_POST['target_url'] ) ) : '';
        $status     = isset( $_POST['status_code'] ) ? absint( $_POST['status_code'] ) : 301;
        $is_regex   = isset( $_POST['is_regex'] ) ? 1 : 0;

        $source = csrm_normalize_source( $raw_source, $is_regex );

        if ( empty( $source ) || empty( $raw_target ) ) {
            $errors[] = __( 'Source and target URLs are required.', 'custom-seo-redirection-manager' );
        }

        if ( ! in_array( $status, array( 301, 302, 307 ), true ) ) {
            $errors[] = __( 'Please choose a valid status code (301, 302 or 307).', 'custom-seo-redirection-manager' );
        }

        if ( $is_regex && $source && false === csrm_validate_regex_pattern( $source ) ) {
            $errors[] = __( 'That regular expression is not valid. Please double-check the pattern.', 'custom-seo-redirection-manager' );
        }

        $target = csrm_validate_target_url( $raw_target, $is_regex );

        if ( false === $target ) {
            $errors[] = __( 'Target URL must be a valid absolute URL or a relative path.', 'custom-seo-redirection-manager' );
        }

        if ( empty( $errors ) ) {

            $wpdb->replace(
                $table,
                array(
                    'source_url'  => $source,
                    'target_url'  => $target,
                    'status_code' => $status,
                    'is_regex'    => $is_regex,
                ),
                array( '%s', '%s', '%d', '%d' )
            );

            echo '<div class="notice notice-success"><p>' . esc_html__( 'Redirect saved successfully.', 'custom-seo-redirection-manager' ) . '</p></div>';
        }
    }

    if ( ! empty( $errors ) ) {
        foreach ( $errors as $error ) {
            echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
        }
    }

    if (
        isset( $_GET['delete'] ) &&
        isset( $_GET['_wpnonce'] ) &&
        wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'csrm_delete_redirect' )
    ) {

        $wpdb->delete(
            $table,
            array( 'id' => absint( $_GET['delete'] ) ),
            array( '%d' )
        );

        echo '<div class="notice notice-success"><p>' . esc_html__( 'Redirect deleted.', 'custom-seo-redirection-manager' ) . '</p></div>';
    }

    $per_page     = 20;
    $current_page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
    $offset       = ( $current_page - 1 ) * $per_page;

    $total_items = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

    $redirects = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        )
    );

    ?>

    <div class="wrap">

        <h1><?php esc_html_e( 'Custom SEO Redirection Manager', 'custom-seo-redirection-manager' ); ?></h1>

        <form method="post" class="csrm-card">

            <?php wp_nonce_field( 'csrm_save_redirect', 'csrm_nonce' ); ?>

            <table class="form-table">

                <tr>
                    <th><?php esc_html_e( 'Source URL', 'custom-seo-redirection-manager' ); ?></th>
                    <td>
                        <input
                            type="text"
                            name="source_url"
                            class="regular-text"
                            required
                            placeholder="<?php esc_attr_e( 'old-page', 'custom-seo-redirection-manager' ); ?>"
                        >
                    </td>
                </tr>

                <tr>
                    <th><?php esc_html_e( 'Target URL', 'custom-seo-redirection-manager' ); ?></th>
                    <td>
                        <input
                            type="text"
                            name="target_url"
                            class="regular-text"
                            required
                            placeholder="<?php esc_attr_e( 'new-page or https://example.com', 'custom-seo-redirection-manager' ); ?>"
                        >
                    </td>
                </tr>

                <tr>
                    <th><?php esc_html_e( 'Status Code', 'custom-seo-redirection-manager' ); ?></th>
                    <td>
                        <select name="status_code">
                            <option value="301"><?php esc_html_e( '301 Permanent', 'custom-seo-redirection-manager' ); ?></option>
                            <option value="302"><?php esc_html_e( '302 Temporary', 'custom-seo-redirection-manager' ); ?></option>
                            <option value="307"><?php esc_html_e( '307 Temporary', 'custom-seo-redirection-manager' ); ?></option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th><?php esc_html_e( 'Regex Redirect', 'custom-seo-redirection-manager' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="is_regex" value="1">
                            <?php esc_html_e( 'Enable Regex', 'custom-seo-redirection-manager' ); ?>
                        </label>
                    </td>
                </tr>

            </table>

            <p>
                <input
                    type="submit"
                    name="csrm_add_redirect"
                    class="button button-primary"
                    value="<?php esc_attr_e( 'Save Redirect', 'custom-seo-redirection-manager' ); ?>"
                >
            </p>

        </form>

        <div class="csrm-card">

            <h2><?php esc_html_e( 'Import / Export', 'custom-seo-redirection-manager' ); ?></h2>

            <p>
                <a
                    class="button"
                    href="<?php echo esc_url(
                        wp_nonce_url(
                            admin_url( 'admin.php?page=csrm-redirects&csrm_export=1' ),
                            'csrm_export_redirects'
                        )
                    ); ?>"
                >
                    <?php esc_html_e( 'Export CSV', 'custom-seo-redirection-manager' ); ?>
                </a>
            </p>

            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'csrm_import_redirects', 'csrm_import_nonce' ); ?>
                <input type="file" name="csrm_csv" accept=".csv" required>
                <input
                    type="submit"
                    name="csrm_import_csv"
                    class="button"
                    value="<?php esc_attr_e( 'Import CSV', 'custom-seo-redirection-manager' ); ?>"
                >
            </form>

        </div>

        <h2 class="csrm-section-heading"><?php esc_html_e( 'Redirect Rules', 'custom-seo-redirection-manager' ); ?></h2>

        <table class="wp-list-table widefat striped">

            <thead>
                <tr>
                    <th><?php esc_html_e( 'ID', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Source', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Target', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Type', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Regex', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Hits', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Action', 'custom-seo-redirection-manager' ); ?></th>
                </tr>
            </thead>

            <tbody>

            <?php if ( ! empty( $redirects ) ) : ?>

                <?php foreach ( $redirects as $row ) : ?>

                    <tr>

                        <td><?php echo (int) $row->id; ?></td>

                        <td><?php echo esc_html( $row->source_url ); ?></td>

                        <td><?php echo esc_html( $row->target_url ); ?></td>

                        <td><?php echo (int) $row->status_code; ?></td>

                        <td>
                            <?php echo $row->is_regex
                                ? esc_html__( 'Yes', 'custom-seo-redirection-manager' )
                                : esc_html__( 'No', 'custom-seo-redirection-manager' ); ?>
                        </td>

                        <td><?php echo (int) $row->hit_count; ?></td>

                        <td>

                            <a
                                class="csrm-confirm-delete"
                                href="<?php echo esc_url(
                                    wp_nonce_url(
                                        admin_url(
                                            'admin.php?page=csrm-redirects&delete=' . absint( $row->id )
                                        ),
                                        'csrm_delete_redirect'
                                    )
                                ); ?>"
                            >
                                <?php esc_html_e( 'Delete', 'custom-seo-redirection-manager' ); ?>
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else : ?>

                <tr>
                    <td colspan="7">
                        <?php esc_html_e( 'No redirects found.', 'custom-seo-redirection-manager' ); ?>
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

        <?php
        $total_pages = (int) ceil( $total_items / $per_page );

        if ( $total_pages > 1 ) :
            ?>
            <div class="tablenav">
                <div class="tablenav-pages">
                    <?php
                    echo wp_kses_post(
                        paginate_links(
                            array(
                                'base'      => add_query_arg( 'paged', '%#%' ),
                                'format'    => '',
                                'current'   => $current_page,
                                'total'     => $total_pages,
                                'prev_text' => __( '&laquo;', 'custom-seo-redirection-manager' ),
                                'next_text' => __( '&raquo;', 'custom-seo-redirection-manager' ),
                            )
                        )
                    );
                    ?>
                </div>
            </div>
            <?php
        endif;
        ?>

    </div>

    <?php
}
