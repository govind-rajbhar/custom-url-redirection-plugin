<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'template_redirect', 'csrm_process_redirects', 1 );

/**
 * Pick a PCRE delimiter that does not appear inside the admin-supplied
 * pattern, so a literal '#' (or whichever delimiter) in the pattern can't
 * break the expression.
 *
 * @return string|false Delimiter character, or false if none of the
 *                       candidates are safe to use.
 */
function csrm_pick_regex_delimiter( $pattern ) {

    $candidates = array( '~', '#', '!', '%', '@' );

    foreach ( $candidates as $delimiter ) {
        if ( false === strpos( $pattern, $delimiter ) ) {
            return $delimiter;
        }
    }

    return false;
}

/**
 * Validate that a pattern compiles as a safe, usable PCRE regex.
 *
 * @return string|false The delimiter to use if valid, false otherwise.
 */
function csrm_validate_regex_pattern( $pattern ) {

    if ( '' === $pattern || strlen( $pattern ) > 255 ) {
        return false; // Matches the DB column limit; also a light length guard.
    }

    $delimiter = csrm_pick_regex_delimiter( $pattern );

    if ( false === $delimiter ) {
        return false;
    }

    $is_valid = @preg_match( $delimiter . $pattern . $delimiter, '' );

    return ( false === $is_valid ) ? false : $delimiter;
}

function csrm_process_redirects() {

    if ( is_admin() ) {
        return;
    }

    global $wpdb;

    $table = csrm_get_redirect_table();

    $request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $current_path = trim( (string) parse_url( $request_uri, PHP_URL_PATH ), '/' );

    if ( empty( $current_path ) ) {
        return;
    }

    $redirect = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE source_url = %s LIMIT 1",
            $current_path
        )
    );

    if ( $redirect ) {
        csrm_execute_redirect( $redirect, $redirect->target_url );
        return;
    }

    $regex_rules = $wpdb->get_results(
        "SELECT * FROM {$table} WHERE is_regex = 1 ORDER BY id ASC"
    );

    if ( empty( $regex_rules ) ) {
        return;
    }

    // Light, temporary mitigation against runaway backtracking on
    // admin-authored regex patterns; restored immediately after matching.
    $previous_backtrack_limit = ini_get( 'pcre.backtrack_limit' );
    ini_set( 'pcre.backtrack_limit', '1000000' );

    foreach ( $regex_rules as $rule ) {

        $delimiter = csrm_validate_regex_pattern( $rule->source_url );

        if ( false === $delimiter ) {
            continue; // Skip malformed/unsafe patterns instead of failing the request.
        }

        $matched = @preg_match( $delimiter . $rule->source_url . $delimiter, $current_path );

        if ( 1 === $matched ) {

            $target = @preg_replace(
                $delimiter . $rule->source_url . $delimiter,
                $rule->target_url,
                $current_path
            );

            if ( null !== $target ) {
                csrm_execute_redirect( $rule, $target );
            }

            break;
        }
    }

    ini_set( 'pcre.backtrack_limit', $previous_backtrack_limit );
}

function csrm_execute_redirect( $redirect, $target ) {

    global $wpdb;

    $table = csrm_get_redirect_table();

    if ( empty( $target ) ) {
        return;
    }

    $is_absolute = ( 0 === strpos( $target, 'http://' ) || 0 === strpos( $target, 'https://' ) );

    if ( $is_absolute ) {

        // $target originates from a row an administrator (manage_options
        // capability, nonce-verified) saved — not from the current
        // request — but it is still validated as a well-formed URL
        // before a visitor is ever redirected to it.
        if ( ! wp_http_validate_url( $target ) ) {
            return;
        }

        $target_url = esc_url_raw( $target );

    } else {

        $target_url = home_url( '/' . ltrim( $target, '/' ) );
    }

    if ( empty( $target_url ) ) {
        return;
    }

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $current_url = home_url( (string) parse_url( $request_uri, PHP_URL_PATH ) );

    if ( untrailingslashit( $current_url ) === untrailingslashit( $target_url ) ) {
        return;
    }

    $wpdb->update(
        $table,
        array( 'hit_count' => intval( $redirect->hit_count ) + 1 ),
        array( 'id' => absint( $redirect->id ) ),
        array( '%d' ),
        array( '%d' )
    );

    $allowed_codes = array( 301, 302, 307 );

    $status_code = in_array( intval( $redirect->status_code ), $allowed_codes, true )
        ? intval( $redirect->status_code )
        : 301;

    // wp_redirect() is used deliberately (rather than wp_safe_redirect())
    // because the destination is trusted, validated, admin-authored data —
    // this is what makes cross-domain 301s configured by the site owner
    // (a common SEO migration use case) actually work, instead of being
    // silently swallowed by wp_safe_redirect()'s same-host allow-list.
    wp_redirect( $target_url, $status_code );
    exit;
}
