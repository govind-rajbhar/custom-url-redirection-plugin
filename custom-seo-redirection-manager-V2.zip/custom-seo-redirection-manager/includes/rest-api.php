<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'rest_api_init', 'csrm_register_rest_routes' );

/**
 * Shared permission_callback for every csrm/v1 route. WordPress core
 * automatically validates the X-WP-Nonce header (action "wp_rest") for
 * cookie-authenticated requests before this even runs, so this callback
 * only needs to enforce the capability check.
 */
function csrm_rest_permission_check() {
    return current_user_can( 'manage_options' );
}

function csrm_register_rest_routes() {

    register_rest_route(
        'csrm/v1',
        '/404-logs/(?P<id>\d+)',
        array(
            'methods'             => 'DELETE',
            'callback'            => 'csrm_rest_delete_404_log',
            'permission_callback' => 'csrm_rest_permission_check',
            'args'                => array(
                'id' => array(
                    'required'          => true,
                    'validate_callback' => function ( $param ) {
                        return is_numeric( $param );
                    },
                    'sanitize_callback' => 'absint',
                ),
            ),
        )
    );

    register_rest_route(
        'csrm/v1',
        '/404-logs',
        array(
            'methods'             => 'DELETE',
            'callback'            => 'csrm_rest_clear_404_logs',
            'permission_callback' => 'csrm_rest_permission_check',
        )
    );
}

function csrm_rest_delete_404_log( WP_REST_Request $request ) {

    $id = absint( $request->get_param( 'id' ) );

    if ( ! $id ) {
        return new WP_Error(
            'csrm_invalid_id',
            __( 'Invalid log id.', 'custom-seo-redirection-manager' ),
            array( 'status' => 400 )
        );
    }

    csrm_delete_404_log( $id );

    return rest_ensure_response( array( 'deleted' => $id ) );
}

function csrm_rest_clear_404_logs( WP_REST_Request $request ) {

    csrm_clear_404_logs();

    return rest_ensure_response( array( 'cleared' => true ) );
}
