<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_init', 'csrm_handle_export' );
add_action( 'admin_init', 'csrm_handle_import' );

/**
 * Prevent CSV/formula injection: if a cell starts with a character a
 * spreadsheet app would interpret as the start of a formula, prefix it
 * with a single quote so it's treated as plain text on open.
 */
function csrm_csv_safe_cell( $value ) {

    $value = (string) $value;

    if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
        return "'" . $value;
    }

    return $value;
}

/**
 * Trust a file's .csv extension for wp_handle_upload()'s real-MIME check.
 * See the comment at the call site for why this is needed.
 */
function csrm_trust_csv_extension( $data, $file, $filename, $mimes ) {

    if ( ! empty( $filename ) && 'csv' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
        $data['ext']  = 'csv';
        $data['type'] = 'text/csv';
    }

    return $data;
}

function csrm_upload_error_message( $error_code ) {

    $messages = array(
        UPLOAD_ERR_INI_SIZE   => __( 'That file is larger than this server allows (upload_max_filesize).', 'custom-seo-redirection-manager' ),
        UPLOAD_ERR_FORM_SIZE  => __( 'That file is larger than the form allows.', 'custom-seo-redirection-manager' ),
        UPLOAD_ERR_PARTIAL    => __( 'The file was only partially uploaded. Please try again.', 'custom-seo-redirection-manager' ),
        UPLOAD_ERR_NO_TMP_DIR => __( 'The server is missing a temporary folder for uploads.', 'custom-seo-redirection-manager' ),
        UPLOAD_ERR_CANT_WRITE => __( 'The server could not write the uploaded file to disk.', 'custom-seo-redirection-manager' ),
        UPLOAD_ERR_EXTENSION  => __( 'A server extension stopped the file upload.', 'custom-seo-redirection-manager' ),
    );

    return isset( $messages[ $error_code ] )
        ? $messages[ $error_code ]
        : __( 'The file upload failed for an unknown reason.', 'custom-seo-redirection-manager' );
}

function csrm_admin_notice_error( $message ) {

    add_action(
        'admin_notices',
        function () use ( $message ) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
        }
    );
}

function csrm_handle_export() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! isset( $_GET['csrm_export'] ) || ! isset( $_GET['_wpnonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'csrm_export_redirects' ) ) {
        return;
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    global $wpdb;

    $table = csrm_get_redirect_table();

    $rows = $wpdb->get_results(
        "SELECT source_url,target_url,status_code,is_regex,hit_count FROM {$table}",
        ARRAY_A
    );

    nocache_headers();
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=redirects.csv' );

    $output = fopen( 'php://output', 'w' );

    fputcsv( $output, array( 'source_url', 'target_url', 'status_code', 'is_regex', 'hit_count' ) );

    if ( ! empty( $rows ) ) {
        foreach ( $rows as $row ) {
            fputcsv( $output, array_map( 'csrm_csv_safe_cell', $row ) );
        }
    }

    fclose( $output );
    exit;
}

function csrm_handle_import() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! isset( $_POST['csrm_import_csv'] ) || ! isset( $_POST['csrm_import_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['csrm_import_nonce'] ) ), 'csrm_import_redirects' ) ) {
        return;
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( empty( $_FILES['csrm_csv'] ) ) {
        return;
    }

    $upload_error = isset( $_FILES['csrm_csv']['error'] ) ? (int) $_FILES['csrm_csv']['error'] : UPLOAD_ERR_NO_FILE;

    if ( UPLOAD_ERR_NO_FILE === $upload_error ) {
        return; // No file was chosen; nothing to do.
    }

    if ( UPLOAD_ERR_OK !== $upload_error ) {
        // Surface failures that happen before wp_handle_upload() even runs
        // (e.g. the file exceeded upload_max_filesize), which previously
        // failed silently with no notice at all.
        csrm_admin_notice_error( csrm_upload_error_message( $upload_error ) );
        return;
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $upload_overrides = array(
        'test_form' => false,
        'mimes'     => array( 'csv' => 'text/csv' ),
    );

    // WordPress' fileinfo-based MIME sniff frequently reports a plain CSV
    // (no quoting/special bytes for it to key off) as text/plain rather
    // than text/csv, which makes wp_handle_upload() reject a perfectly
    // valid .csv file. This filter is scoped to this one call and only
    // trusts files that already have a .csv extension — reasonable here
    // since the upload is already nonce + manage_options gated above.
    add_filter( 'wp_check_filetype_and_ext', 'csrm_trust_csv_extension', 10, 4 );

    $movefile = wp_handle_upload( $_FILES['csrm_csv'], $upload_overrides );

    remove_filter( 'wp_check_filetype_and_ext', 'csrm_trust_csv_extension', 10 );

    if ( ! $movefile || isset( $movefile['error'] ) ) {

        $message = isset( $movefile['error'] )
            ? $movefile['error']
            : __( 'Could not read the uploaded file.', 'custom-seo-redirection-manager' );

        csrm_admin_notice_error( $message );

        return;
    }

    $file_path = $movefile['file'];
    $file      = fopen( $file_path, 'r' );

    if ( ! $file ) {
        @unlink( $file_path );
        return;
    }

    global $wpdb;

    $table      = csrm_get_redirect_table();
    $row_number = 0;
    $imported   = 0;
    $skipped    = 0;

    while ( ( $row = fgetcsv( $file, 2000, ',' ) ) !== false ) {

        $row_number++;

        if ( 1 === $row_number ) {
            continue; // Header row.
        }

        $source = isset( $row[0] ) ? sanitize_text_field( wp_unslash( $row[0] ) ) : '';
        $target = isset( $row[1] ) ? sanitize_text_field( wp_unslash( $row[1] ) ) : '';
        $status = isset( $row[2] ) ? absint( $row[2] ) : 301;
        $regex  = ( isset( $row[3] ) && '1' === trim( (string) $row[3] ) ) ? 1 : 0;

        // Strip a full domain off the source if one was pasted/exported
        // in (mirrors the manual "Add Redirect" form's behavior) — see
        // csrm_normalize_source() for why this is regex-safe.
        $source = csrm_normalize_source( $source, $regex );

        if ( empty( $source ) || empty( $target ) ) {
            $skipped++;
            continue;
        }

        if ( ! in_array( $status, array( 301, 302, 307 ), true ) ) {
            $status = 301;
        }

        if ( $regex && false === csrm_validate_regex_pattern( $source ) ) {
            $skipped++;
            continue;
        }

        $safe_target = csrm_validate_target_url( $target, $regex );

        if ( false === $safe_target ) {
            $skipped++;
            continue;
        }

        $wpdb->replace(
            $table,
            array(
                'source_url'  => $source,
                'target_url'  => $safe_target,
                'status_code' => $status,
                'is_regex'    => $regex,
            ),
            array( '%s', '%s', '%d', '%d' )
        );

        $imported++;
    }

    fclose( $file );
    @unlink( $file_path ); // One-off import file — not meant to persist in the media library.

    add_action(
        'admin_notices',
        function () use ( $imported, $skipped ) {
            printf(
                '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                esc_html(
                    sprintf(
                        /* translators: 1: rows imported, 2: rows skipped */
                        __( 'CSV imported: %1$d row(s) saved, %2$d row(s) skipped.', 'custom-seo-redirection-manager' ),
                        $imported,
                        $skipped
                    )
                )
            );
        }
    );
}
