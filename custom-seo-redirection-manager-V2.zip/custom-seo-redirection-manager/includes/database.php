<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function csrm_get_redirect_table() {
    global $wpdb;
    return $wpdb->prefix . 'custom_redirects';
}

function csrm_get_404_table() {
    global $wpdb;
    return $wpdb->prefix . 'custom_404_logs';
}

function csrm_activate_plugin() {

    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();

    $redirect_table = csrm_get_redirect_table();
    $logs_table     = csrm_get_404_table();

    $redirect_sql = "CREATE TABLE {$redirect_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        source_url VARCHAR(255) NOT NULL,
        target_url VARCHAR(255) NOT NULL,
        status_code SMALLINT(3) NOT NULL DEFAULT 301,
        is_regex TINYINT(1) NOT NULL DEFAULT 0,
        hit_count BIGINT(20) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY source_url (source_url)
    ) {$charset_collate};";

    $logs_sql = "CREATE TABLE {$logs_table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_url VARCHAR(255) NOT NULL,
        hits BIGINT(20) NOT NULL DEFAULT 1,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY request_url (request_url)
    ) {$charset_collate};";

    dbDelta( $redirect_sql );
    dbDelta( $logs_sql );

    update_option( 'csrm_db_version', CSRM_VERSION );
}

/**
 * Re-run dbDelta() whenever the plugin version changes, so future schema
 * changes are applied automatically without requiring a
 * deactivate/reactivate cycle.
 */
add_action( 'admin_init', 'csrm_maybe_upgrade_db' );
function csrm_maybe_upgrade_db() {

    if ( get_option( 'csrm_db_version' ) !== CSRM_VERSION ) {
        csrm_activate_plugin();
    }
}
