<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'template_redirect', 'csrm_track_404', 999 );

function csrm_track_404() {

    if ( ! is_404() || is_admin() ) {
        return;
    }

    global $wpdb;

    $table = csrm_get_404_table();

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $path        = trim( (string) parse_url( $request_uri, PHP_URL_PATH ), '/' );

    if ( empty( $path ) ) {
        return;
    }

    $existing = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE request_url = %s LIMIT 1",
            $path
        )
    );

    if ( $existing ) {

        $wpdb->update(
            $table,
            array(
                'hits'      => intval( $existing->hits ) + 1,
                'last_seen' => current_time( 'mysql' ),
            ),
            array( 'id' => absint( $existing->id ) ),
            array( '%d', '%s' ),
            array( '%d' )
        );

    } else {

        $wpdb->insert(
            $table,
            array(
                'request_url' => $path,
                'hits'        => 1,
                'last_seen'   => current_time( 'mysql' ),
            ),
            array( '%s', '%d', '%s' )
        );
    }
}

function csrm_get_404_logs( $limit = 100 ) {

    global $wpdb;

    $table = csrm_get_404_table();
    $limit = absint( $limit );

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY hits DESC, last_seen DESC LIMIT %d",
            $limit
        )
    );
}

function csrm_delete_404_log( $id ) {

    global $wpdb;

    $table = csrm_get_404_table();

    return $wpdb->delete(
        $table,
        array( 'id' => absint( $id ) ),
        array( '%d' )
    );
}

function csrm_clear_404_logs() {

    global $wpdb;

    $table = csrm_get_404_table();

    return $wpdb->query( "TRUNCATE TABLE {$table}" );
}

/**
 * Render the 404 Monitor admin screen. Row actions (delete/clear) are
 * handled client-side by assets/js/admin.js via the authenticated REST
 * routes registered in includes/rest-api.php.
 */
function csrm_404_monitor_page() {

    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $logs = csrm_get_404_logs( 200 );

    ?>
    <div class="wrap">

        <h1><?php esc_html_e( '404 Monitor', 'custom-seo-redirection-manager' ); ?></h1>

        <p>
            <button type="button" class="button" id="csrm-clear-404-logs">
                <?php esc_html_e( 'Clear All Logs', 'custom-seo-redirection-manager' ); ?>
            </button>
        </p>

        <table class="wp-list-table widefat striped" id="csrm-404-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Requested URL', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Hits', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Last Seen', 'custom-seo-redirection-manager' ); ?></th>
                    <th><?php esc_html_e( 'Action', 'custom-seo-redirection-manager' ); ?></th>
                </tr>
            </thead>
            <tbody>

            <?php if ( ! empty( $logs ) ) : ?>

                <?php foreach ( $logs as $log ) : ?>
                    <tr data-log-id="<?php echo esc_attr( $log->id ); ?>">
                        <td><?php echo esc_html( $log->request_url ); ?></td>
                        <td><?php echo (int) $log->hits; ?></td>
                        <td><?php echo esc_html( $log->last_seen ); ?></td>
                        <td>
                            <button
                                type="button"
                                class="button-link-delete csrm-delete-404-log"
                                data-id="<?php echo esc_attr( $log->id ); ?>"
                            >
                                <?php esc_html_e( 'Delete', 'custom-seo-redirection-manager' ); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>

            <?php else : ?>

                <tr>
                    <td colspan="4">
                        <?php esc_html_e( 'No 404s logged yet.', 'custom-seo-redirection-manager' ); ?>
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>
        </table>

    </div>
    <?php
}
