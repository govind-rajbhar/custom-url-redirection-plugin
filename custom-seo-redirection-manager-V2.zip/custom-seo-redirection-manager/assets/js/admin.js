( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {

		// Confirm before following any "Delete" link on the redirects screen.
		document.querySelectorAll( '.csrm-confirm-delete' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				if ( ! window.confirm( CSRM_Admin.confirmDelete ) ) {
					e.preventDefault();
				}
			} );
		} );

		var table = document.getElementById( 'csrm-404-table' );

		if ( table ) {
			table.addEventListener( 'click', function ( e ) {

				var btn = e.target.closest( '.csrm-delete-404-log' );

				if ( ! btn ) {
					return;
				}

				if ( ! window.confirm( CSRM_Admin.confirmDelete ) ) {
					return;
				}

				var id  = btn.getAttribute( 'data-id' );
				var row = btn.closest( 'tr' );

				fetch( CSRM_Admin.restUrl + '404-logs/' + id, {
					method: 'DELETE',
					headers: { 'X-WP-Nonce': CSRM_Admin.nonce }
				} ).then( function ( response ) {
					if ( response.ok && row ) {
						row.remove();
					}
				} );
			} );
		}

		var clearBtn = document.getElementById( 'csrm-clear-404-logs' );

		if ( clearBtn ) {
			clearBtn.addEventListener( 'click', function () {

				if ( ! window.confirm( CSRM_Admin.confirmClear ) ) {
					return;
				}

				fetch( CSRM_Admin.restUrl + '404-logs', {
					method: 'DELETE',
					headers: { 'X-WP-Nonce': CSRM_Admin.nonce }
				} ).then( function ( response ) {
					if ( response.ok ) {
						window.location.reload();
					}
				} );
			} );
		}
	} );
} )();
