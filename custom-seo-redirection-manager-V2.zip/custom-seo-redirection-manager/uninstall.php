<?php
/**
 * Fires only when the plugin is deleted from the Plugins screen (not on
 * simple deactivation). WordPress defines WP_UNINSTALL_PLUGIN itself
 * before including this file, so that constant — not ABSPATH — is the
 * correct guard here.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$redirect_table = $wpdb->prefix . 'custom_redirects';
$logs_table     = $wpdb->prefix . 'custom_404_logs';

$wpdb->query( "DROP TABLE IF EXISTS {$redirect_table}" );
$wpdb->query( "DROP TABLE IF EXISTS {$logs_table}" );

delete_option( 'csrm_db_version' );
