<?php
/**
 * Plugin Name: Custom SEO Redirection Manager
 * Description: SEO Redirect Manager with Regex, Hit Counter, 404 Monitoring and CSV Import/Export.
 * Version: 1.1.0
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * Author: Govind
 * Text Domain: custom-seo-redirection-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Block direct file access.
}

define( 'CSRM_VERSION', '1.1.0' );
define( 'CSRM_PATH', plugin_dir_path( __FILE__ ) );
define( 'CSRM_URL', plugin_dir_url( __FILE__ ) );

require_once CSRM_PATH . 'includes/database.php';
require_once CSRM_PATH . 'includes/redirects.php';
require_once CSRM_PATH . 'includes/admin-page.php';
require_once CSRM_PATH . 'includes/import-export.php';
require_once CSRM_PATH . 'includes/404-monitor.php';
require_once CSRM_PATH . 'includes/rest-api.php';

register_activation_hook( __FILE__, 'csrm_activate_plugin' );

/**
 * Load translations from /languages if any are ever shipped.
 */
add_action( 'plugins_loaded', 'csrm_load_textdomain' );
function csrm_load_textdomain() {
    load_plugin_textdomain(
        'custom-seo-redirection-manager',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}
